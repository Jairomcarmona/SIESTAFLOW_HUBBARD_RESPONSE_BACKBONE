"""Selección sobre datos ya calculados; nunca lanza ni cambia un cálculo.

Codex deberá suministrar observaciones compatibles y momentos seleccionados
semánticamente. Todos los canales BARE/SCREENED relevantes deben entrar juntos.
"""

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class AlphaPolicy:
    occupation_noise: float
    residual_relative: float = 0.02
    slope_relative: float = 0.05
    min_signal_to_noise: float = 10.0
    magnetic_tolerance: float = 0.05


def select_alpha(alphas, occupations, moments, initial_alpha, policy,
                 magnetic_states=None, override=None):
    """Ajusta ventanas ±h/2, ±h, ±2h; override no elude los rechazos.

occupations: (7, canales), momentos: (7, sitios, 3), alpha en eV.
override: {alpha, actor, reason}; devuelve diagnósticos serializables.
La incertidumbre corresponde a la pendiente, no a una distribución de alpha.
"""
    thresholds = np.asarray(list(vars(policy).values()), dtype=float)
    if not np.all(np.isfinite(thresholds)) or np.any(thresholds <= 0):
        raise ValueError("Política: umbrales positivos y finitos obligatorios")
    if not np.isfinite(initial_alpha) or initial_alpha <= 0:
        raise ValueError("initial_alpha debe ser positivo y finito")
    amplitudes = initial_alpha * np.array([0.5, 1.0, 2.0])
    expected = np.array([-2, -1, -0.5, 0, 0.5, 1, 2]) * initial_alpha
    axis = np.asarray(alphas, dtype=float)
    values = np.asarray(occupations, dtype=float)
    magnetic = np.asarray(moments, dtype=float)
    if values.ndim == 1:
        values = values[:, None]
    if (axis.shape != (7,) or values.ndim != 2 or values.shape[0] != 7
            or values.shape[1] == 0 or magnetic.ndim != 3
            or magnetic.shape[0] != 7 or magnetic.shape[1] == 0
            or magnetic.shape[2] != 3):
        raise ValueError("Se requieren siete puntos y momentos vectoriales")
    if not all(np.all(np.isfinite(array)) for array in (axis, values, magnetic)):
        raise ValueError("Datos no finitos")
    order = np.argsort(axis)
    axis, values, magnetic = axis[order], values[order], magnetic[order]
    if not np.allclose(axis, expected, rtol=1e-12, atol=0):
        raise ValueError("Malla incompleta, duplicada o no centrada")
    states_changed = False
    if magnetic_states is not None:
        if len(magnetic_states) != 7 or any(not state for state in magnetic_states):
            raise ValueError("Etiquetas magnéticas incompletas")
        states_changed = len(set(magnetic_states)) != 1
    magnetic_deviation = float(np.max(np.linalg.norm(magnetic - magnetic[3], axis=2)))
    magnetic_changed = states_changed or magnetic_deviation > policy.magnetic_tolerance
    central_slopes = []
    for amplitude in amplitudes:
        minus = int(np.argmin(abs(axis + amplitude)))
        plus = int(np.argmin(abs(axis - amplitude)))
        central_slopes.append((values[plus] - values[minus]) / (2 * amplitude))
    central_slopes = np.array(central_slopes)
    windows = []
    for index, amplitude in enumerate(amplitudes):
        selected = abs(axis) <= amplitude * (1 + 1e-12)
        window_axis, window_values = axis[selected], values[selected]
        intercept = window_values.mean(axis=0)
        denominator = float(window_axis @ window_axis)
        if not np.isfinite(denominator) or denominator <= 0:
            raise ValueError("Escala de alpha fuera del rango numérico del ajuste")
        slope = window_axis @ window_values / denominator
        residuals = window_values - intercept - window_axis[:, None] * slope
        rms = np.sqrt(np.mean(residuals**2, axis=0))
        variance = np.maximum(np.sum(residuals**2, axis=0) / (len(window_axis) - 2),
                              policy.occupation_noise**2)
        stderr = np.sqrt(variance / denominator)
        comparison = central_slopes[:max(2, index + 1)]
        dispersion = np.std(comparison, axis=0)
        drift = np.max(abs(comparison - slope), axis=0)
        signal = abs(slope) * amplitude
        if not all(np.all(np.isfinite(array)) for array in
                   (intercept, slope, residuals, rms, stderr, dispersion, drift, signal)):
            raise ValueError("Diagnósticos no finitos: no emitir recomendación")
        reasons = []
        if magnetic_changed:
            reasons.append("cambio_de_estado_magnetico")
        if np.any(signal < policy.min_signal_to_noise * policy.occupation_noise):
            reasons.append("senal_no_resuelta")
        if np.any(np.max(abs(residuals), axis=0) >
                  3 * policy.occupation_noise + policy.residual_relative * signal):
            reasons.append("residuo_no_lineal")
        if np.any(drift > policy.slope_relative * abs(slope) + 3 * stderr):
            reasons.append("pendiente_inestable_entre_escalas")
        windows.append({
            "alpha": float(amplitude), "interval": [-float(amplitude), float(amplitude)],
            "intercept": intercept.tolist(), "slope": slope.tolist(),
            "residual_rms": rms.tolist(), "residual_max": np.max(abs(residuals), axis=0).tolist(),
            "dispersion": dispersion.tolist(), "slope_standard_error": stderr.tolist(),
            "slope_uncertainty": (stderr + drift).tolist(),
            "eligible": not reasons, "reasons": reasons,
        })
    eligible = [window for window in windows if window["eligible"]]
    chosen = eligible[-1] if eligible else None
    audit_override = None
    if override is not None:
        if (set(override) != {"alpha", "actor", "reason"}
                or not isinstance(override["actor"], str) or not override["actor"].strip()
                or not isinstance(override["reason"], str) or not override["reason"].strip()
                or not np.isfinite(override["alpha"])):
            raise ValueError("Override requiere alpha, actor y motivo")
        matches = [window for window in eligible
                   if np.isclose(window["alpha"], override["alpha"], rtol=1e-12, atol=0)]
        audit_override = dict(override, applied=bool(matches))
        chosen = matches[0] if matches else None
    return {
        "status": "proposed" if chosen else "rejected",
        "recommended_alpha": chosen["alpha"] if chosen else None,
        "evaluated_interval": [-float(amplitudes[-1]), float(amplitudes[-1])],
        "selected_interval": chosen["interval"] if chosen else None,
        "slope_uncertainty": chosen["slope_uncertainty"] if chosen else None,
        "reason": ("mayor_ventana_admisible" if override is None else "override_registrado")
                  if chosen else "sin_ventana_admisible_o_override_rechazado",
        "magnetic_deviation": magnetic_deviation, "windows": windows,
        "override": audit_override, "policy": dict(vars(policy)),
    }