"""Reconstrucción escalar certificada; sin simetrización ni pseudoinversa.

Codex deberá conectar las identidades de filas/columnas a observaciones auditadas.
No cubre representaciones orbitales ni reconstrucción con inversión temporal.
"""

from dataclasses import dataclass

import numpy as np

from .symmetry_reduction_proposal import SymmetryCertificate, _digest


@dataclass(frozen=True)
class ChannelCertificate:
    source: SymmetryCertificate
    row_sites: tuple
    column_sites: tuple
    permutations: tuple
    digest: str

    def verify(self):
        self.source.verify()
        expected = certify_channels(self.source, self.row_sites, self.column_sites)
        if self.digest != expected.digest or self.permutations != expected.permutations:
            raise ValueError("Certificado de canales alterado")


def certify_channels(symmetry, row_sites, column_sites):
    """Un canal escalar por sitio; órdenes de filas y columnas independientes."""
    symmetry.verify()
    if not symmetry.reduction_enabled:
        raise ValueError("Reducción no certificada")
    count = symmetry.site_count
    if any(sorted(sites) != list(range(count)) for sites in (row_sites, column_sites)):
        raise ValueError("Canales deben ser biyecciones de los sitios certificados")
    row_sites, column_sites = tuple(row_sites), tuple(column_sites)
    operations = []
    for operation in symmetry.magnetic_operations:
        row_map = tuple(row_sites.index(operation.permutation[site]) for site in row_sites)
        column_map = tuple(column_sites.index(operation.permutation[site]) for site in column_sites)
        if (row_map, column_map) not in operations:
            operations.append((row_map, column_map))
    payload = {"source": symmetry.digest, "rows": row_sites, "columns": column_sites,
               "permutations": operations}
    return ChannelCertificate(symmetry, row_sites, column_sites, tuple(operations), _digest(payload))


def _positive(value, name):
    if not np.isfinite(value) or value <= 0:
        raise ValueError(f"{name} debe ser positivo y finito")


def _square(matrix):
    matrix = np.asarray(matrix, dtype=float)
    if (matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1] or matrix.shape[0] == 0
            or not np.all(np.isfinite(matrix))):
        raise ValueError("Matriz cuadrada, finita y no vacía requerida")
    return matrix


def diagnostics(matrix, condition_limit=1e8, inversion_tolerance=1e-10):
    """Rango SVD y residuos izquierdo/derecho; no regulariza modos nulos."""
    matrix = _square(matrix)
    _positive(condition_limit, "condition_limit")
    _positive(inversion_tolerance, "inversion_tolerance")
    singular = np.linalg.svd(matrix, compute_uv=False)
    tolerance = len(matrix) * np.finfo(float).eps * singular[0]
    rank = int(np.count_nonzero(singular > tolerance))
    if rank != len(matrix):
        raise ValueError("Matriz singular: no invertir ni usar pseudoinversa")
    condition = float(singular[0] / singular[-1])
    if condition > condition_limit:
        raise ValueError("Matriz mal condicionada")
    inverse = np.linalg.inv(matrix)
    identity = np.eye(len(matrix))
    left = float(np.linalg.norm(inverse @ matrix - identity, ord=np.inf))
    right = float(np.linalg.norm(matrix @ inverse - identity, ord=np.inf))
    if not np.isfinite(left + right) or max(left, right) > inversion_tolerance:
        raise ValueError("Residuo de inversión excesivo")
    return {"rank": rank, "condition": condition, "rank_tolerance": float(tolerance),
            "singular_values": singular.tolist(), "left_residual": left,
            "right_residual": right, "inverse": inverse}


def reconstruct(columns, certificate, validation_columns, absolute_tolerance=1e-9,
                relative_tolerance=1e-6, condition_limit=1e8):
    """Cada órbita reducida necesita una columna explícita de control independiente.

columns y validation_columns: diccionarios índice -> vector de derivadas.
Los controles no se utilizan para generar la matriz. La comparación no es
una prueba de simetría física universal, sólo del alcance sintético certificado.
"""
    if not isinstance(certificate, ChannelCertificate):
        raise ValueError("Certificado de simetría obligatorio")
    certificate.verify()
    _positive(absolute_tolerance, "absolute_tolerance")
    _positive(relative_tolerance, "relative_tolerance")
    count = certificate.source.site_count
    if not columns or set(columns) & set(validation_columns):
        raise ValueError("Separar semillas y controles explícitos")
    for collection in (columns, validation_columns):
        for index, vector in collection.items():
            if (type(index) is not int or not 0 <= index < count
                    or np.asarray(vector).shape != (count,)
                    or not np.all(np.isfinite(np.asarray(vector, dtype=float)))):
                raise ValueError("Índice o dimensión de columna inválido")
    known = {index: np.array(vector, dtype=float, copy=True) for index, vector in columns.items()}
    sources = {index: {"seed": index, "operations": []} for index in known}
    while True:
        previous_count = len(known)
        for operation_index, (row_map, column_map) in enumerate(certificate.permutations):
            for index, vector in list(known.items()):
                destination = column_map[index]
                transformed = np.empty(count)
                transformed[list(row_map)] = vector
                if destination in known:
                    if not np.allclose(known[destination], transformed,
                                       atol=absolute_tolerance, rtol=relative_tolerance):
                        raise ValueError("Columnas incompatibles con la simetría")
                else:
                    known[destination] = transformed
                    sources[destination] = {"seed": sources[index]["seed"],
                                            "operations": sources[index]["operations"] + [operation_index]}
        if len(known) == previous_count:
            break
    if len(known) != count:
        raise ValueError("Faltan representantes: no rellenar columnas con ceros")
    for orbit in certificate.source.orbits:
        channel_orbit = {certificate.column_sites.index(site) for site in orbit}
        if channel_orbit - set(columns) and not channel_orbit & set(validation_columns):
            raise ValueError("Falta control explícito para una órbita reducida")
    validation_residuals = {}
    for index, vector in validation_columns.items():
        validation_residuals[index] = float(np.max(abs(known[index] - vector)))
        if not np.allclose(known[index], vector, atol=absolute_tolerance, rtol=relative_tolerance):
            raise ValueError("Reconstrucción contradice una columna calculada explícitamente")
    matrix = np.column_stack([known[index] for index in range(count)])
    report = diagnostics(matrix, condition_limit=condition_limit)
    symmetry_residuals = []
    for row_map, column_map in certificate.permutations:
        row_matrix = np.eye(count)[:, list(row_map)]
        column_matrix = np.eye(count)[:, list(column_map)]
        transformed = row_matrix @ matrix @ column_matrix.T
        residual = float(np.max(abs(matrix - transformed)))
        symmetry_residuals.append(residual)
        if not np.allclose(matrix, transformed, atol=absolute_tolerance, rtol=relative_tolerance):
            raise ValueError("Residuo de simetría excesivo")
        if np.linalg.matrix_rank(transformed) != report["rank"]:
            raise ValueError("Rango no preservado por las permutaciones")
    return {"matrix": matrix, "diagnostics": report, "sources": sources,
            "validation_residuals": validation_residuals,
            "symmetry_residuals": symmetry_residuals, "certificate": certificate.digest}


def cococcioni_kernel(chi0, chi, row_ids, column_ids, condition_limit=1e8):
    """K=(chi0)^-1-chi^-1; mismo orden físico en ambos ejes antes de invertir."""
    chi0, chi = _square(chi0), _square(chi)
    if (chi0.shape != chi.shape or len(row_ids) != len(chi)
            or len(set(row_ids)) != len(row_ids) or tuple(row_ids) != tuple(column_ids)):
        raise ValueError("Dimensiones o identidades de canales incompatibles")
    bare = diagnostics(chi0, condition_limit)
    screened = diagnostics(chi, condition_limit)
    if bare["rank"] != screened["rank"]:
        raise ValueError("Rangos BARE/SCREENED distintos")
    kernel = bare["inverse"] - screened["inverse"]
    return {"kernel": kernel, "U": np.diag(kernel).copy(), "bare": bare, "screened": screened}