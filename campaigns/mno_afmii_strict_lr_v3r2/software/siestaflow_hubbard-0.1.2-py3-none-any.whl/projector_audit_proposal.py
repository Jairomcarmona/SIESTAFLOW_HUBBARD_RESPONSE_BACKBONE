"""Auditor de metadatos FDF/PSML, no certificación de funciones radiales.

El lector PSML es intencionadamente limitado y falla de forma conservadora:
no deduce orbitales Hubbard a partir de canales no locales del pseudopotencial.
Codex debe adaptar la extracción FDF y auditar el .dftu_proj real posteriormente.
"""

from hashlib import sha256
import math
import xml.etree.ElementTree as ET


def psml_metadata(content):
    """Lee pseudo-atom-spec y shell[n,l] en valence-configuration, con namespace."""
    if not isinstance(content, bytes) or not content or len(content) > 8_000_000:
        raise ValueError("PSML debe ser bytes no vacíos y acotados")
    if b"<!DOCTYPE" in content.upper() or b"<!ENTITY" in content.upper():
        raise ValueError("Entidades XML no admitidas")
    root = ET.fromstring(content)
    local_name = lambda node: node.tag.rsplit("}", 1)[-1]
    if local_name(root) != "psml":
        raise ValueError("Raíz PSML inválida")
    atoms = [node for node in root.iter() if local_name(node) == "pseudo-atom-spec"]
    if len(atoms) != 1:
        raise ValueError("Identidad atómica PSML ausente o ambigua")
    atom = atoms[0]
    species = atom.get("atomic-label")
    atomic_number = int(atom.get("atomic-number", "0"))
    if not species or not 1 <= atomic_number <= 118:
        raise ValueError("Identidad atómica PSML incompleta")
    shells = set()
    for configuration in root.iter():
        if local_name(configuration) == "valence-configuration":
            for node in configuration.iter():
                if local_name(node) == "shell" and node.get("n") and node.get("l"):
                    principal, orbital = int(node.get("n")), int(node.get("l"))
                    if not 0 <= orbital < principal:
                        raise ValueError("Números cuánticos PSML inválidos")
                    shells.add((principal, orbital))
    return {"species": species, "atomic_number": atomic_number,
            "shells": shells, "sha256": sha256(content).hexdigest()}


def audit_projectors(projectors, subspaces, psml_by_species, equivalent_orbits=()):
    """Devuelve rejected, warning o provisional_acceptance, nunca aprobación física.

rc_bohr es el radio Hubbard declarado, NO el radio del pseudopotencial.
Una selección parcial de m requiere una representación orbital no implementada.
"""
    if not projectors or len(projectors) != len(subspaces):
        raise ValueError("Proyectores/subespacios vacíos o incompatibles")
    reports = []
    required = {"species", "atomic_number", "n", "l", "shell", "m_values",
                "rc_bohr", "method", "pseudo_sha256"}
    for index, (projector, subspace) in enumerate(zip(projectors, subspaces)):
        rejected, warnings = [], []
        if not isinstance(projector, dict) or not required <= projector.keys():
            rejected.append("definicion_de_proyector_incompleta")
        else:
            principal, orbital = projector["n"], projector["l"]
            quantum_valid = (type(principal) is int and type(orbital) is int
                             and 0 <= orbital <= 3 and principal > orbital)
            if not quantum_valid:
                rejected.append("numeros_cuanticos_no_admitidos")
            else:
                if projector["shell"] != f"{principal}{'spdf'[orbital]}":
                    rejected.append("shell_incompatible")
                magnetic_numbers = projector["m_values"]
                if (not isinstance(magnetic_numbers, (list, tuple)) or not magnetic_numbers
                        or any(type(value) is not int or abs(value) > orbital for value in magnetic_numbers)
                        or len(set(magnetic_numbers)) != len(magnetic_numbers)):
                    rejected.append("canales_m_invalidos")
                elif sorted(magnetic_numbers) != list(range(-orbital, orbital + 1)):
                    warnings.append("subespacio_parcial_requiere_representacion_orbital")
            radius = projector["rc_bohr"]
            if (not isinstance(radius, (int, float)) or isinstance(radius, bool)
                    or not math.isfinite(radius) or radius <= 0):
                rejected.append("radio_de_corte_invalido")
            if projector["method"] not in ("method1", "method2"):
                rejected.append("metodo_no_admitido")
            if not isinstance(subspace, dict) or any(
                subspace.get(key) != projector[key] for key in ("species", "n", "l", "m_values")
            ) or not subspace.get("occupation_definition"):
                rejected.append("subespacio_incompatible_o_incompleto")
            try:
                pseudo = psml_metadata(psml_by_species[projector["species"]])
                if (pseudo["species"] != projector["species"]
                        or pseudo["atomic_number"] != projector["atomic_number"]
                        or pseudo["sha256"] != projector["pseudo_sha256"]):
                    rejected.append("identidad_PSML_incompatible")
                if not pseudo["shells"]:
                    warnings.append("PSML_sin_shells_interpretables")
                elif (principal, orbital) not in pseudo["shells"]:
                    rejected.append("shell_no_respaldado_por_valencia_PSML")
            except (KeyError, ValueError, TypeError, ET.ParseError):
                rejected.append("PSML_ausente_o_no_interpretable")
        reports.append({"site": index, "rejections": rejected, "warnings": warnings})
    seen = set()
    for orbit in equivalent_orbits:
        if (not orbit or any(type(site) is not int or not 0 <= site < len(projectors) for site in orbit)
                or len(set(orbit)) != len(orbit) or seen & set(orbit)):
            raise ValueError("Órbitas inválidas o solapadas")
        seen.update(orbit)
        reference = orbit[0]
        if any(projectors[site] != projectors[reference] or subspaces[site] != subspaces[reference]
               for site in orbit):
            for site in orbit:
                reports[site]["rejections"].append("definiciones_distintas_en_sitios_equivalentes")
    for report in reports:
        report["status"] = ("rejected" if report["rejections"] else
                            "warning" if report["warnings"] else "provisional_acceptance")
    status = ("rejected" if any(report["rejections"] for report in reports) else
              "warning" if any(report["warnings"] for report in reports) else "provisional_acceptance")
    return {"status": status, "sites": reports,
            "pending": ["funcion_radial_real", "normalizacion_y_soporte", "sensibilidad_de_U_al_proyector"]}