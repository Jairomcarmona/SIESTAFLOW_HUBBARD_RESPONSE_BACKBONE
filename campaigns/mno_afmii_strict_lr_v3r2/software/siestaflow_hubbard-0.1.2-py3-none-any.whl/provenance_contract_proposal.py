"""Contrato científico aislado. Un hash vincula bytes, no prueba su física.

Codex deberá producir el plan confiable y comprobar hashes, lectura de DM y
semántica SCF contra artefactos reales; este módulo no ejecuta ni parsea SIESTA.
"""

from dataclasses import asdict, dataclass
from hashlib import sha256
import json
import math
import re


def canonical_bytes(payload):
    """Perfil JSON Python restringido: claves string, UTF-8, finitos, sin duplicados."""
    def validate(value):
        if value is None or type(value) in (str, bool, int):
            return
        if type(value) is float and math.isfinite(value):
            return
        if isinstance(value, (list, tuple)):
            for member in value:
                validate(member)
            return
        if type(value) is dict and all(type(key) is str for key in value):
            for member in value.values():
                validate(member)
            return
        raise ValueError("Valor fuera del perfil JSON canónico")
    validate(payload)
    return json.dumps(payload, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def content_hash(payload):
    return sha256(canonical_bytes(payload)).hexdigest()


def valid_hash(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


@dataclass(frozen=True)
class RunIdentity:
    campaign: str
    step: str
    mode: str
    alpha_ev: float
    observed_channel: str
    perturbed_channel: str
    fdf_sha256: str
    pseudos: tuple
    parent_dm_sha256: str
    subspace_sha256: str
    projector_sha256: str
    physical_model_sha256: str
    runtime_sha256: str
    magnetic_reference_sha256: str
    selector_policy_sha256: str


@dataclass(frozen=True)
class Observation:
    identity: RunIdentity
    occupation: float
    output_sha256: str
    scf_state: str
    scf_evidence_sha256: str
    dm_read_verified: bool
    complete: bool
    return_code: int


def validate_observation(observation, expected):
    """BARE usa bare_selected_verified; SCREENED exige converged_verified."""
    identity = observation.identity
    if identity != expected:
        raise ValueError("Identidad distinta del plan confiable")
    for name in ("campaign", "step", "observed_channel", "perturbed_channel"):
        if not isinstance(getattr(identity, name), str) or not getattr(identity, name).strip():
            raise ValueError("Identificador vacío")
    if identity.mode not in ("BARE", "SCREENED") or not math.isfinite(identity.alpha_ev):
        raise ValueError("Modo o alpha inválido")
    for name, value in asdict(identity).items():
        if name.endswith("sha256") and not valid_hash(value):
            raise ValueError(f"Hash requerido: {name}")
    if (not identity.pseudos or any(not isinstance(item, tuple) or len(item) != 2
                                  or not isinstance(item[0], str) or not item[0]
                                  or not valid_hash(item[1]) for item in identity.pseudos)
            or len({item[0] for item in identity.pseudos}) != len(identity.pseudos)
            or tuple(sorted(identity.pseudos)) != identity.pseudos):
        raise ValueError("Pseudos deben ser pares únicos y ordenados etiqueta/hash")
    if not valid_hash(observation.output_sha256) or not valid_hash(observation.scf_evidence_sha256):
        raise ValueError("Salida o evidencia SCF sin hash")
    expected_state = {"BARE": "bare_selected_verified", "SCREENED": "converged_verified"}[identity.mode]
    if (observation.complete is not True or observation.dm_read_verified is not True
            or type(observation.return_code) is not int or observation.return_code != 0
            or observation.scf_state != expected_state or not math.isfinite(observation.occupation)):
        raise ValueError("Observación incompleta o sin evidencia semántica positiva")
    return content_hash(asdict(observation))


def validate_analysis(observations, expected_by_step, required_alphas,
                      required_modes=("BARE", "SCREENED")):
    """Un par de canales por lote; no mezcla DMs ni políticas de selección.

El FDF puede variar por alpha/modo, pero debe coincidir con el plan de su paso.
physical_model_sha256 identifica el modelo sin esas dos variaciones autorizadas.
"""
    if (not observations or not required_alphas or not required_modes
            or any(not math.isfinite(value) for value in required_alphas)
            or len(set(required_alphas)) != len(required_alphas)
            or len(set(required_modes)) != len(required_modes)
            or set(required_modes) - {"BARE", "SCREENED"}):
        raise ValueError("Lote o malla inválidos")
    invariant_fields = ("campaign", "observed_channel", "perturbed_channel", "pseudos",
                        "parent_dm_sha256", "subspace_sha256", "projector_sha256",
                        "physical_model_sha256", "runtime_sha256", "magnetic_reference_sha256",
                        "selector_policy_sha256")
    reference = observations[0].identity
    seen, steps, hashes = set(), set(), []
    for observation in observations:
        identity = observation.identity
        if identity.step not in expected_by_step:
            raise ValueError("Paso no planificado")
        hashes.append(validate_observation(observation, expected_by_step[identity.step]))
        for field in invariant_fields:
            if getattr(identity, field) != getattr(reference, field):
                raise ValueError(f"Observaciones incompatibles: {field}")
        key = (identity.mode, identity.alpha_ev)
        if key in seen or identity.step in steps:
            raise ValueError("Duplicado: réplicas requieren una política explícita")
        seen.add(key)
        steps.add(identity.step)
    expected_keys = {(mode, alpha) for mode in required_modes for alpha in required_alphas}
    if seen != expected_keys:
        raise ValueError("Resultados incompletos o puntos no previstos")
    return {"status": "compatible_for_proposed_analysis", "observation_hashes": hashes,
            "parent_dm_sha256": reference.parent_dm_sha256,
            "analysis_input_hash": content_hash(sorted(hashes))}