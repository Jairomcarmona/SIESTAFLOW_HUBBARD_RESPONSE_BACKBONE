"""Journal JSON append-only para filesystem local POSIX y escritores cooperativos.

No es una base de datos ni adaptador del scheduler. Recibos inmutables y eventos
son autoridad; no hay HEAD mutable. Un lock abandonado requiere confirmar fuera
de este módulo que el escritor murió. No se roba un lock por timeout o PID.
"""

from contextlib import contextmanager
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import stat
import uuid

from .provenance_contract_proposal import canonical_bytes, valid_hash


class StoreError(ValueError):
    """Estado corrupto o petición inválida."""


class WriterBusy(StoreError):
    """Existe un lock: no se conoce si su escritor sigue vivo."""


class StaleWriter(StoreError):
    """Versión esperada o token de escritor obsoleto."""


def _strict_load(content):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise StoreError("Clave JSON duplicada")
            result[key] = value
        return result
    try:
        result = json.loads(content, object_pairs_hook=pairs)
        canonical_bytes(result)
        return result
    except (ValueError, UnicodeError, TypeError) as error:
        raise StoreError("JSON inválido o no finito") from error


class JsonStateStore:
    """Una revisión global CAS; transiciones técnicas separadas de aceptación científica."""

    def __init__(self, root):
        self.root = Path(root)
        if self.root.is_absolute() or ".." in self.root.parts:
            raise StoreError("Usar ruta relativa sin componentes '..'")
        cursor = Path(".")
        for component in self.root.parts:
            cursor /= component
            if cursor.is_symlink():
                raise StoreError("Directorio simbólico no permitido")
        self.root.mkdir(parents=True, exist_ok=True)
        for name in ("events", "receipts", "recovery"):
            directory = self.root / name
            if directory.is_symlink():
                raise StoreError("Directorio simbólico no permitido")
            directory.mkdir(exist_ok=True)
        self.lock_path = self.root / "writer.lock"

    def _read(self, path):
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(descriptor, "rb") as stream:
            details = os.fstat(stream.fileno())
            if not stat.S_ISREG(details.st_mode) or details.st_nlink != 1 or details.st_size > 2_000_000:
                raise StoreError("Artefacto no regular, enlazado o demasiado grande")
            return stream.read()

    def _sync_directory(self, directory):
        descriptor = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    def _verify_token(self, token):
        try:
            lock = _strict_load(self._read(self.lock_path))
        except (OSError, StoreError) as error:
            raise StaleWriter("Lock perdido") from error
        if lock.get("token") != token:
            raise StaleWriter("Token de escritor obsoleto")

    @contextmanager
    def _locked(self):
        token = uuid.uuid4().hex
        try:
            descriptor = os.open(self.lock_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        except FileExistsError as error:
            raise WriterBusy("Lock presente; no se roba automáticamente") from error
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(canonical_bytes({"token": token, "pid": os.getpid()}))
            stream.flush()
            os.fsync(stream.fileno())
        self._sync_directory(self.root)
        try:
            yield token
        finally:
            self._verify_token(token)
            self.lock_path.unlink()
            self._sync_directory(self.root)

    def _publish(self, path, content, token):
        self._verify_token(token)
        if path.exists() or path.is_symlink():
            if self._read(path) != content:
                raise StoreError("Intento de sobrescribir un artefacto inmutable")
            return
        temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
        descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(content)
            stream.flush()
            os.fchmod(stream.fileno(), 0o400)
            os.fsync(stream.fileno())
        self._verify_token(token)
        os.rename(temporary, path)
        self._sync_directory(path.parent)

    def _validate_payload(self, payload, tasks):
        if set(payload) != {"task_id", "state", "evidence"}:
            raise StoreError("Esquema de evento inválido")
        task, state, evidence = payload["task_id"], payload["state"], payload["evidence"]
        if not isinstance(task, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", task):
            raise StoreError("task_id inválido")
        transitions = {None: {"planned"}, "planned": {"running", "failed"},
                       "running": {"failed", "artifact_complete_not_scientific_acceptance"},
                       "failed": set(), "artifact_complete_not_scientific_acceptance": set()}
        previous = tasks.get(task, {}).get("state")
        if not isinstance(state, str) or state not in transitions[previous] or not isinstance(evidence, dict):
            raise StoreError("Transición técnica inválida; reintentar con otro task_id")
        if state == "artifact_complete_not_scientific_acceptance":
            if (evidence.get("complete") is not True or type(evidence.get("return_code")) is not int
                    or evidence["return_code"] != 0 or any(not valid_hash(evidence.get(name)) for name in
                    ("output_sha256", "parent_dm_sha256", "runtime_sha256", "fdf_sha256"))):
                raise StoreError("Resultado técnico incompleto")
        if state == "failed" and (not isinstance(evidence.get("reason"), str)
                                  or not evidence["reason"].strip()):
            raise StoreError("Fallo sin motivo")
        canonical_bytes(payload)

    def _replay(self):
        previous_hash, revision, tasks, referenced = "0" * 64, 0, {}, set()
        for path in sorted((self.root / "events").glob("*.json")):
            revision += 1
            if path.name != f"{revision:020d}.json":
                raise StoreError("Hueco o nombre inválido en el journal")
            content = self._read(path)
            event = _strict_load(content)
            if (not isinstance(event, dict) or set(event) != {"schema", "revision", "previous_sha256", "receipt_sha256"}
                    or event["schema"] != 1 or type(event["revision"]) is not int
                    or event["revision"] != revision or event["previous_sha256"] != previous_hash
                    or not valid_hash(event["receipt_sha256"]) or canonical_bytes(event) != content):
                raise StoreError("Cadena de eventos corrupta")
            receipt_hash = event["receipt_sha256"]
            try:
                receipt_bytes = self._read(self.root / "receipts" / f"{receipt_hash}.json")
            except OSError as error:
                raise StoreError("Recibo ausente") from error
            if sha256(receipt_bytes).hexdigest() != receipt_hash:
                raise StoreError("Hash del recibo no coincide")
            payload = _strict_load(receipt_bytes)
            if not isinstance(payload, dict):
                raise StoreError("Recibo inválido")
            self._validate_payload(payload, tasks)
            tasks[payload["task_id"]] = payload
            referenced.add(receipt_hash)
            previous_hash = sha256(content).hexdigest()
        orphans = sorted(path.name for path in (self.root / "receipts").glob("*.json")
                         if path.stem not in referenced)
        temporaries = sorted(str(path.relative_to(self.root)) for path in self.root.glob("*/*.tmp"))
        return {"revision": revision, "head_sha256": previous_hash, "tasks": tasks,
                "orphan_receipts": orphans, "temporary_files": temporaries}

    def snapshot(self):
        with self._locked():
            return self._replay()

    def _checkpoint(self, stage):
        """Punto de inyección de caída usado sólo por las pruebas sintéticas."""

    def append(self, task_id, state, evidence, expected_revision):
        with self._locked() as token:
            snapshot = self._replay()
            if type(expected_revision) is not int or expected_revision != snapshot["revision"]:
                raise StaleWriter("Revisión CAS obsoleta")
            payload = {"task_id": task_id, "state": state, "evidence": evidence}
            self._validate_payload(payload, snapshot["tasks"])
            receipt = canonical_bytes(payload)
            if len(receipt) > 2_000_000:
                raise StoreError("Recibo demasiado grande")
            receipt_hash = sha256(receipt).hexdigest()
            self._publish(self.root / "receipts" / f"{receipt_hash}.json", receipt, token)
            self._checkpoint("after_receipt")
            revision = snapshot["revision"] + 1
            event = {"schema": 1, "revision": revision,
                     "previous_sha256": snapshot["head_sha256"], "receipt_sha256": receipt_hash}
            self._publish(self.root / "events" / f"{revision:020d}.json", canonical_bytes(event), token)
            self._checkpoint("after_event")
            return revision

    def recover_abandoned_lock(self, token, operator, reason, confirmed_writer_stopped=False):
        """SOLO mantenimiento exclusivo con escritor muerto confirmado externamente.

CONTRACT GAP: determinar muerte de trabajos y evitar procesos huérfanos no
corresponde a este almacén. Sin esa evidencia, conservar lock y fallar cerrado.
"""
        if (confirmed_writer_stopped is not True or not isinstance(operator, str) or not operator.strip()
                or not isinstance(reason, str) or not reason.strip()):
            raise StoreError("Recuperación requiere confirmación externa, operador y motivo")
        self._verify_token(token)
        audit = canonical_bytes({"abandoned_token": token, "operator": operator, "reason": reason,
                                 "confirmed_writer_stopped": True})
        self._publish(self.root / "recovery" / f"{uuid.uuid4().hex}.json", audit, token)
        self._verify_token(token)
        self.lock_path.unlink()
        self._sync_directory(self.root)
        return self.snapshot()