# Acceptance Policy
